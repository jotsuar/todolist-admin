<?php

$config = array(
	'ADMIN_ROLE'      => 'administrador',
	'ENABLED_VALUE'   => '1',
	'DISABLED_VALUE'  => '0',
	'OTHER_ROLE'   => 'generico',
	'Application' => array(
		'name' 	  => 'TodoList',
		'version' => 'v0.7',
		'status'  => 1,
		'maintenance' => 0
	),
	'Meta' => array(
		'title' 	  => 'TodoList',
		'description' => 'TodoList',
		'keywords' 	  => 'TodoList',
	),
	'Google' => array(
		'analytics'  => '',
	),
);

?>
